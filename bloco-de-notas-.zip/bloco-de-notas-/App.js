import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, ScrollView, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [paciente, setPaciente] = useState(''); // Nome do paciente
  const [medicamento, setMedicamento] = useState(''); // Nome do medicamento
  const [dosagem, setDosagem] = useState(''); // Dosagem do medicamento
  const [hora, setHora] = useState(''); // Hora de administração
  const [registros, setRegistros] = useState([]); // Lista de registros de medicação

  // Função para carregar os registros salvos
  const loadRegistros = async () => {
    try {
      const storedRegistros = await AsyncStorage.getItem('registros');
      if (storedRegistros) {
        setRegistros(JSON.parse(storedRegistros));
      }
    } catch (error) {
      console.error('Erro ao carregar registros', error);
    }
  };

  // Função para salvar um novo registro de medicação
  const saveRegistro = async () => {
    if (paciente.trim() === '' || medicamento.trim() === '' || dosagem.trim() === '' || hora.trim() === '') {
      alert('Por favor, preencha todos os campos.');
      return;
    }

    // Pega a data e hora atual
    const currentDate = new Date();
    const timeStamp = `${currentDate.toLocaleDateString()} ${currentDate.toLocaleTimeString()}`;

    // Cria um novo registro com os dados informados
    const novoRegistro = {
      paciente,
      medicamento,
      dosagem,
      hora,
      timestamp: timeStamp
    };

    const novosRegistros = [...registros, novoRegistro];
    setRegistros(novosRegistros);
    setPaciente('');
    setMedicamento('');
    setDosagem('');
    setHora('');

    try {
      await AsyncStorage.setItem('registros', JSON.stringify(novosRegistros));
    } catch (error) {
      console.error('Erro ao salvar registro', error);
    }
  };

  // Função para excluir um registro
  const deleteRegistro = (index) => {
    const novosRegistros = registros.filter((_, i) => i !== index);
    setRegistros(novosRegistros);
    
    AsyncStorage.setItem('registros', JSON.stringify(novosRegistros));
  };

  // Carrega os registros quando o app é iniciado
  useEffect(() => {
    loadRegistros();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Bloco de Notas - Medicações</Text>

      <TextInput
        style={styles.input}
        value={paciente}
        onChangeText={setPaciente}
        placeholder="Nome do Paciente"
      />
      <TextInput
        style={styles.input}
        value={medicamento}
        onChangeText={setMedicamento}
        placeholder="Nome do Medicamento"
      />
      <TextInput
        style={styles.input}
        value={dosagem}
        onChangeText={setDosagem}
        placeholder="Dosagem (Ex: 2 comprimidos)"
      />
      <TextInput
        style={styles.input}
        value={hora}
        onChangeText={setHora}
        placeholder="Horário de Administração (Ex: 08:00 AM)"
      />
      <Button title="Salvar Registro" onPress={saveRegistro} />

      <ScrollView style={styles.registrosContainer}>
        {registros.map((registro, index) => (
          <View key={index} style={styles.registro}>
            <Text style={styles.registroText}>Paciente: {registro.paciente}</Text>
            <Text style={styles.registroText}>Medicamento: {registro.medicamento}</Text>
            <Text style={styles.registroText}>Dosagem: {registro.dosagem}</Text>
            <Text style={styles.registroText}>Horário: {registro.hora}</Text>
            <Text style={styles.registroText}>Registrado em: {registro.timestamp}</Text>
            <Button title="Excluir" onPress={() => deleteRegistro(index)} />
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f7f7f7',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingLeft: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  registrosContainer: {
    marginTop: 20,
  },
  registro: {
    backgroundColor: '#fff',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  registroText: {
    fontSize: 16,
    marginBottom: 5,
  },
});
